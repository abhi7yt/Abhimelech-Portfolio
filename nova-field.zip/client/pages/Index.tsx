import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github,
  ExternalLink,
  Calendar,
  Award,
  Briefcase,
  GraduationCap,
  Code,
  Database,
  BarChart3,
  FileText,
  Download,
  ArrowRight,
  Star,
  TrendingUp,
  Target,
  Zap,
  Building,
  Users,
  Brain,
  LineChart,
  BookOpen,
  Trophy,
  Lightbulb,
  ChevronRight,
  DollarSign,
  TrendingDown,
} from "lucide-react";
import { useState } from "react";

export default function Index() {
  const [activeTab, setActiveTab] = useState("experience");

  const technicalSkills = {
    "Programming Languages": ["Python", "R"],
    "Tools & Technologies": [
      "Jira",
      "Google Analytics",
      "Colab",
      "Google BigQuery",
    ],
    "Data Visualization Tools": ["Tableau", "Power BI", "Looker"],
    "Microsoft Office Suite": [
      "Visio",
      "Excel",
      "Word",
      "PowerPoint",
      "MS Outlook",
    ],
  };

  const experiences = [
    {
      title: "Business Analyst and Technology Intern",
      company: "Parking Base Inc.",
      period: "February 2025 – June 2025",
      type: "Internship",
      location: "New York, United States of America",
      achievements: [
        "Developed Looker dashboards and migrated 500K+ records related to Healthcare Claims Processing",
        "Supported implementation of new ERP system, improving data accuracy by 15%",
        "Led requirements gathering for contact center systems using agile methodologies and Scrum framework",
        "Collaborated with Data Engineering team to design and implement a new data pipeline for processing 15 million records per day",
        "Created compelling PowerPoint presentations and technical documentation including data mapping",
      ],
      projects: [
        {
          name: "Revenue Analytics & Data Migration",
          description:
            "Built a Looker reporting System & migrated 500K+ records to databases, improving financial insights & delivering analytical briefings for cross-team decision-making for stakeholders in Accounting",
        },
      ],
      icon: <Briefcase className="h-5 w-5" />,
      color: "from-blue-500 to-blue-600",
      metrics: { records: "500K+", accuracy: "+15%", dailyRecords: "15M" },
    },
    {
      title: "Graduate Analyst, R&D Division",
      company: "Feliciano School of Business, Montclair State University",
      period: "August 2023 – December 2024",
      type: "Academic Research",
      location: "New Jersey",
      achievements: [
        "Led research initiative analyzing cross-pet ownership trends using BigQuery and Python",
        "Supported laboratory research involving HPLC instrumentation, ensuring accurate data collection",
        "Conducted systems analysis using SQL Server and developed business solutions incorporating Project Management best practices",
        "Integrated Portfolio Management and Risk Analytics considerations into solution design, ensuring alignment with financial objectives",
      ],
      projects: [
        {
          name: "Research & Development in Marketing Analytics",
          description:
            "Led a research initiative in collaboration with the Chair of the Marketing Department, utilizing BigQuery and Python to analyze cross-pet ownership trends and spending behavior",
        },
      ],
      icon: <GraduationCap className="h-5 w-5" />,
      color: "from-blue-400 to-blue-500",
      metrics: { publications: "1", projects: "2", presentations: "5+" },
    },
  ];

  const certifications = [
    {
      name: "JPMorgan Chase & Co. Asia Analyst Development Program (AADP)",
      period: "January 2023 – February 2023",
      description:
        "Led eZBike project, conducting data analysis in Excel, and delivered tailored banking solutions. Led RR Accessories acquisition assessment, performing DCF and relative valuation.",
      achievements: [
        "Skilled in treasury management and investment strategies, leveraging financial acumen to optimize resources",
        "Proficient in applying cutting-edge fintech solutions within the banking sector",
        "Experienced in conducting financial analysis and evaluation through various data analysis tools such as SQL and Tableau",
      ],
      icon: <Building className="h-5 w-5" />,
      color: "from-blue-600 to-indigo-600",
    },
    {
      name: "JPMorgan Chase & Co. Global Finance and Business Management",
      period: "December 2022 - January 2023",
      description:
        "Utilized Excel and Jump to build financial models and performed scenario analyses to identify opportunities and mitigate risks.",
      achievements: [
        "Created dynamic pivot tables and charts in Excel to present financial trends and insights for executive decision-makers",
        "Utilized Advanced Excel to organize and visualize, created charts and graphs to support comprehensive analysis",
      ],
      icon: <DollarSign className="h-5 w-5" />,
      color: "from-green-600 to-teal-600",
    },
    {
      name: "Citi APAC Investment Banking",
      period: "December 2022 - January 2023",
      description:
        "Examined Zeta Inc.'s business history and objectives, built a business strategy regression model using Excel and a dataset of comparable companies.",
      achievements: [
        "Utilized Excel to calculate key financial metrics, including FV/EBITDA multiples, P/E multiples, Dividend Yield, Net Margin, Revenue, Net Debt/EBITDA, and Revenue CAGR",
        "Conducted in-depth financial analysis and strategy development for investment banking projects, utilizing Excel to evaluate company performance",
      ],
      icon: <TrendingUp className="h-5 w-5" />,
      color: "from-purple-600 to-pink-600",
    },
    {
      name: "BCG Strategy Consulting",
      period: "November 2022 - December 2022",
      description:
        "Conducted thorough data analysis to identify market trends, consumer preferences, and performance metrics, enabling data-driven strategies.",
      achievements: [
        "Delivered client-specific solutions that maximized customer satisfaction and presented findings using data visualization tools like Tableau and Power BI",
        "Demonstrated proficiency in Statistical modeling techniques, providing in-depth consumer insights and trend predictions",
      ],
      icon: <Users className="h-5 w-5" />,
      color: "from-orange-600 to-red-600",
    },
    {
      name: "KPMG AU Data Analytics",
      period: "November 2022 - December 2022",
      description:
        "Developed regression models and conducted hypothesis testing to assess statistical significance using MATLAB and Excel for Sprocket Central Pvt Ltd.",
      achievements: [
        "Created interactive dashboards and compelling data visualizations to support and highlight key findings in client presentations using Tableau and Power BI",
        "Transformed raw data through feature engineering, and adept at enriching datasets with external data sourced from the Australian Bureau of Statistics (ABS) and Census",
      ],
      icon: <BarChart3 className="h-5 w-5" />,
      color: "from-indigo-600 to-blue-600",
    },
  ];

  const achievements = [
    {
      title: "Outstanding Graduate Analyst Award (2025)",
      description:
        "Recognized for exceptional mentoring and support to undergraduate students in technical subjects",
      icon: <Trophy className="h-5 w-5" />,
      year: "2025",
    },
    {
      title: "Published Research Paper",
      description: '"Analyzing Cross-Pet Ownership and Spending Behavior"',
      icon: <BookOpen className="h-5 w-5" />,
      year: "2024",
    },
  ];

  const stats = [
    {
      label: "Years Experience",
      value: "2+",
      icon: <Briefcase className="h-5 w-5" />,
    },
    {
      label: "Records Migrated",
      value: "500K+",
      icon: <Database className="h-5 w-5" />,
    },
    {
      label: "Data Accuracy Improved",
      value: "+15%",
      icon: <TrendingUp className="h-5 w-5" />,
    },
    {
      label: "Research Published",
      value: "1",
      icon: <BookOpen className="h-5 w-5" />,
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-blue-100">
        <div className="container-max section-padding py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">AT</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">
                  Abhimelech Tyagi
                </h1>
                <p className="text-sm text-blue-600 font-medium">
                  Business Analyst
                </p>
              </div>
            </div>
            <div className="hidden md:flex space-x-8">
              {[
                "About",
                "Experience",
                "Certifications",
                "Skills",
                "Education",
                "Contact",
              ].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-slate-600 hover:text-blue-600 transition-colors font-medium relative group"
                >
                  {item}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-600 group-hover:w-full transition-all duration-300"></span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="about" className="pt-32 pb-20 section-padding">
        <div className="container-max">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-3 gap-12 items-center">
              <div className="lg:col-span-2 space-y-8">
                <div className="space-y-6">
                  <div className="inline-flex items-center px-4 py-2 bg-blue-50 rounded-full border border-blue-200">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-3 animate-pulse"></div>
                    <span className="text-blue-700 text-sm font-medium">
                      Open to Full-Time Opportunities
                    </span>
                  </div>

                  <div className="space-y-4">
                    <h1 className="text-5xl lg:text-6xl font-bold text-slate-800 leading-tight">
                      Hi, I'm{" "}
                      <span className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-700 bg-clip-text text-transparent">
                        Abhimelech
                      </span>
                    </h1>
                    <h2 className="text-2xl lg:text-3xl text-slate-600 font-medium">
                      Business Analyst
                    </h2>
                  </div>

                  <p className="text-lg text-slate-600 leading-relaxed max-w-2xl">
                    Data-driven professional with 2+ years of experience in
                    business intelligence, analytics, & statistical modeling.
                    Master's in Business Analytics, proficient in SQL, Excel, &
                    Tableau. Skilled in generating actionable insights to
                    support strategic decisions.
                  </p>

                  <div className="flex flex-wrap gap-4">
                    <Button
                      size="lg"
                      className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Contact Me
                      <ArrowRight className="h-4 w-4 ml-2" />
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      className="border-blue-200 text-blue-600 hover:bg-blue-50 hover:border-blue-300"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download Resume
                    </Button>
                  </div>

                  <div className="flex items-center space-x-6 pt-4">
                    <a
                      href="https://www.linkedin.com/in/abhi7t"
                      className="flex items-center justify-center w-12 h-12 bg-blue-50 rounded-xl border border-blue-200 hover:bg-blue-100 transition-all duration-300 group"
                    >
                      <Linkedin className="h-5 w-5 text-blue-600 group-hover:scale-110 transition-transform" />
                    </a>
                    <a
                      href="http://www.github.com/abhi7yt"
                      className="flex items-center justify-center w-12 h-12 bg-blue-50 rounded-xl border border-blue-200 hover:bg-blue-100 transition-all duration-300 group"
                    >
                      <Github className="h-5 w-5 text-blue-600 group-hover:scale-110 transition-transform" />
                    </a>
                    <div className="flex items-center space-x-3 text-slate-600">
                      <MapPin className="h-4 w-4" />
                      <span>New York, United States of America</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4">
                {stats.map((stat, index) => (
                  <Card
                    key={index}
                    className="p-6 bg-white border-blue-100 hover:shadow-lg transition-all duration-300 group"
                  >
                    <div className="space-y-3">
                      <div className="text-blue-600 group-hover:scale-110 transition-transform">
                        {stat.icon}
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-slate-800">
                          {stat.value}
                        </div>
                        <div className="text-sm text-slate-600">
                          {stat.label}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-white section-padding">
        <div className="container-max">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                Professional Experience
              </h2>
              <p className="text-slate-600 text-lg max-w-2xl mx-auto">
                Building expertise through diverse roles in analytics, research,
                and business intelligence
              </p>
            </div>

            <div className="space-y-8">
              {experiences.map((exp, index) => (
                <Card
                  key={index}
                  className="group p-8 border-blue-100 hover:shadow-xl transition-all duration-500 bg-gradient-to-r from-white to-blue-50/30"
                >
                  <div className="space-y-6">
                    <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-6">
                      <div className="flex-1 space-y-4">
                        <div className="flex items-start space-x-4">
                          <div
                            className={`p-3 bg-gradient-to-r ${exp.color} rounded-xl text-white`}
                          >
                            {exp.icon}
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center space-x-3">
                              <h3 className="text-xl font-bold text-slate-800">
                                {exp.title}
                              </h3>
                              <Badge className="bg-blue-100 text-blue-700 border-blue-200">
                                {exp.type}
                              </Badge>
                            </div>
                            <p className="text-blue-600 font-semibold">
                              {exp.company}
                            </p>
                            <div className="flex items-center space-x-4 text-slate-500 text-sm">
                              <div className="flex items-center space-x-1">
                                <Calendar className="h-4 w-4" />
                                <span>{exp.period}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <MapPin className="h-4 w-4" />
                                <span>{exp.location}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="pl-16">
                          <div className="grid md:grid-cols-2 gap-4 mb-6">
                            {Object.entries(exp.metrics).map(([key, value]) => (
                              <div
                                key={key}
                                className="bg-blue-50 rounded-lg p-3"
                              >
                                <div className="text-lg font-bold text-blue-700">
                                  {value}
                                </div>
                                <div className="text-xs text-blue-600 capitalize">
                                  {key.replace(/([A-Z])/g, " $1")}
                                </div>
                              </div>
                            ))}
                          </div>

                          <ul className="space-y-3 mb-6">
                            {exp.achievements.map((achievement, i) => (
                              <li
                                key={i}
                                className="flex items-start space-x-3"
                              >
                                <ChevronRight className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                                <span className="text-slate-700 leading-relaxed">
                                  {achievement}
                                </span>
                              </li>
                            ))}
                          </ul>

                          {/* Projects within experience */}
                          <div className="space-y-3">
                            <h4 className="font-semibold text-slate-800 flex items-center gap-2">
                              <Lightbulb className="h-4 w-4 text-amber-500" />
                              Key Projects:
                            </h4>
                            {exp.projects.map((project, i) => (
                              <div
                                key={i}
                                className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4"
                              >
                                <h5 className="font-semibold text-blue-800 mb-2">
                                  {project.name}
                                </h5>
                                <p className="text-slate-700 text-sm leading-relaxed">
                                  {project.description}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Professional Certifications Section */}
      <section
        id="certifications"
        className="py-20 bg-gradient-to-br from-blue-50 to-indigo-50 section-padding"
      >
        <div className="container-max">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                Professional Certifications
              </h2>
              <p className="text-slate-600 text-lg max-w-2xl mx-auto">
                Comprehensive training from leading financial institutions and
                consulting firms
              </p>
            </div>

            <div className="space-y-8">
              {certifications.map((cert, index) => (
                <Card
                  key={index}
                  className="group p-8 bg-white border-blue-100 hover:shadow-xl transition-all duration-500"
                >
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`p-3 bg-gradient-to-r ${cert.color} rounded-xl text-white flex-shrink-0`}
                      >
                        {cert.icon}
                      </div>
                      <div className="space-y-3 flex-1">
                        <div className="flex flex-col lg:flex-row lg:justify-between lg:items-start gap-3">
                          <div>
                            <h3 className="text-xl font-bold text-slate-800 group-hover:text-blue-700 transition-colors">
                              {cert.name}
                            </h3>
                            <Badge className="bg-blue-100 text-blue-700 border-blue-200 mt-2">
                              {cert.period}
                            </Badge>
                          </div>
                        </div>

                        <p className="text-slate-700 leading-relaxed">
                          {cert.description}
                        </p>

                        <div className="space-y-2">
                          <h4 className="font-semibold text-slate-800 text-sm">
                            Key Achievements:
                          </h4>
                          <ul className="space-y-2">
                            {cert.achievements.map((achievement, i) => (
                              <li
                                key={i}
                                className="flex items-start space-x-3"
                              >
                                <ChevronRight className="h-3 w-3 text-blue-500 mt-1 flex-shrink-0" />
                                <span className="text-slate-600 text-sm leading-relaxed">
                                  {achievement}
                                </span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-white section-padding">
        <div className="container-max">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                Technical Skills
              </h2>
              <p className="text-slate-600 text-lg max-w-2xl mx-auto">
                Core technical competencies for modern data analysis and
                business intelligence
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {Object.entries(technicalSkills).map(
                ([category, skillList], index) => (
                  <Card
                    key={index}
                    className="p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100 hover:shadow-lg transition-all duration-300"
                  >
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <div className="p-2 bg-blue-600 rounded-lg">
                          <Code className="h-5 w-5 text-white" />
                        </div>
                        <h3 className="text-lg font-bold text-slate-800">
                          {category}
                        </h3>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {skillList.map((skill, i) => (
                          <Badge
                            key={i}
                            className="bg-white border-blue-200 text-blue-700 hover:bg-blue-100"
                          >
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Card>
                ),
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Education & Achievements Section */}
      <section
        id="education"
        className="py-20 bg-gradient-to-br from-blue-50 to-slate-50 section-padding"
      >
        <div className="container-max">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                Education & Achievements
              </h2>
              <p className="text-slate-600 text-lg">
                Strong academic foundation and professional recognition
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {/* Education */}
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                  <GraduationCap className="h-6 w-6 text-blue-600" />
                  Education
                </h3>

                <Card className="p-6 bg-white border-blue-100 hover:shadow-lg transition-all duration-300">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Badge className="bg-blue-100 text-blue-700">
                        2023-2024
                      </Badge>
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-800">
                        Master of Science in Business Analytics
                      </h4>
                      <p className="text-blue-600 font-semibold">
                        Montclair State University
                      </p>
                      <p className="text-slate-600 text-sm">
                        Focus on Applied Mathematics and Computer Science
                      </p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-600">
                        Key Courses:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {[
                          "Machine Learning",
                          "AI for Business",
                          "Data Mining",
                          "Regression Analysis",
                          "Supply Chain Management",
                        ].map((course, i) => (
                          <Badge
                            key={i}
                            variant="outline"
                            className="text-xs bg-white border-blue-200"
                          >
                            {course}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 bg-white border-green-100 hover:shadow-lg transition-all duration-300">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Badge className="bg-green-100 text-green-700">
                        2019-2022
                      </Badge>
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-slate-800">
                        Bachelor of Science in Mathematics Honours
                      </h4>
                      <p className="text-green-600 font-semibold">
                        University of Delhi
                      </p>
                      <p className="text-slate-600 text-sm">
                        Strong foundation in statistics and data analytics
                      </p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-600">
                        Key Courses:
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {[
                          "Complex Analysis",
                          "Real Analysis",
                          "Computer Algebra Systems",
                          "Multivariate Calculus",
                          "LaTeX",
                          "HTML",
                        ].map((course, i) => (
                          <Badge
                            key={i}
                            variant="outline"
                            className="text-xs bg-white border-green-200"
                          >
                            {course}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              </div>

              {/* Achievements */}
              <div className="space-y-6">
                <h3 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                  <Award className="h-6 w-6 text-amber-500" />
                  Achievements
                </h3>

                <div className="space-y-4">
                  {achievements.map((achievement, index) => (
                    <Card
                      key={index}
                      className="p-6 bg-white border-amber-100 hover:shadow-lg transition-all duration-300"
                    >
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="text-amber-600">
                              {achievement.icon}
                            </div>
                            <h4 className="font-bold text-slate-800">
                              {achievement.title}
                            </h4>
                          </div>
                          <Badge className="bg-amber-100 text-amber-700">
                            {achievement.year}
                          </Badge>
                        </div>
                        <p className="text-slate-700 leading-relaxed">
                          {achievement.description}
                        </p>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white section-padding">
        <div className="container-max">
          <div className="max-w-5xl mx-auto">
            <Card className="p-8 lg:p-12 bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-100 shadow-xl">
              <div className="space-y-8">
                <div className="text-center">
                  <h2 className="text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
                    Let's Connect
                  </h2>
                  <p className="text-slate-600 text-lg max-w-2xl mx-auto">
                    Ready to discuss data analytics opportunities or collaborate
                    on exciting projects? I'd love to hear from you.
                  </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    {
                      icon: <Mail className="h-6 w-6" />,
                      label: "Email",
                      value: "abhimelecht7@gmail.com",
                      href: "mailto:abhimelecht7@gmail.com",
                    },
                    {
                      icon: <Phone className="h-6 w-6" />,
                      label: "Phone",
                      value: "551-248-6674",
                      href: "tel:551-248-6674",
                    },
                    {
                      icon: <MapPin className="h-6 w-6" />,
                      label: "Location",
                      value: "New York, USA",
                      href: "#",
                    },
                    {
                      icon: <Linkedin className="h-6 w-6" />,
                      label: "LinkedIn",
                      value: "Connect",
                      href: "https://www.linkedin.com/in/abhi7t",
                    },
                  ].map((contact, index) => (
                    <a
                      key={index}
                      href={contact.href}
                      className="group bg-white p-6 rounded-xl border border-blue-100 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                    >
                      <div className="space-y-3 text-center">
                        <div className="text-blue-600 flex justify-center group-hover:scale-110 transition-transform">
                          {contact.icon}
                        </div>
                        <div>
                          <p className="text-blue-500 text-sm font-medium">
                            {contact.label}
                          </p>
                          <p className="text-slate-800 font-semibold text-sm">
                            {contact.value}
                          </p>
                        </div>
                      </div>
                    </a>
                  ))}
                </div>

                <div className="text-center">
                  <Button
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Start a Conversation
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-slate-800 text-white section-padding">
        <div className="container-max">
          <div className="text-center">
            <p className="text-slate-400">
              © 2024 Abhimelech Tyagi. Designed with precision and powered by
              data.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
